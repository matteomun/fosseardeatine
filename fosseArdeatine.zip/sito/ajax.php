<?php
header("Access-Control-Allow-Origin: *");
if(isset($_GET["citta"])){
    $idCitta = $_GET["citta"];
}

$server = "fosseardeatine";
$nameServer = "localhost";
$password = "";
$nameDB = "my_fosseardeatine";

$conn = new mysqli($server, $nameServer, $password, $nameDB);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sqlCitta = 'SELECT descrizione, path_foto, nome, cognome FROM Persona WHERE id_citta =' .$idCitta;
$result = $conn->query($sqlCitta);

if ($result->num_rows > 0) {
    while($colums = $result->fetch_assoc()){
        echo '<div class="foto_person" style="background-image: url('.'foto/'.$colums["path_foto"].');"></div>';
        
        echo "<div class='text_ciociari'>";
        echo '<h3>'.$colums["nome"]." ".$colums["cognome"].'</h3>';
            echo $colums["descrizione"];
        echo "</div>";
    }
}
$conn->close();
?>