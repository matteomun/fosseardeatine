<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fosse ardeatine</title>
    <link rel="stylesheet" href="style.css">
    <script src="java.js"></script>

</head>
<body>
    
    <div class="header_primo" id="headerCentrale">
        <div id="opacity">
            <div id="text"><h1>"Nelle profondità delle Fosse Ardeatine giacciono le vite spezzate di uomini e ragazzi, vittime di un orrore inimmaginabile." <br><h5>5BI IIS A.Volta-Frosinone&nbsp;&nbsp;&nbsp;</h5></h1></div>
        </div>
    </div>

        <?php
        $username = "fosseardeatine";
        $password = "";
        $host = "root";
       $database = "my_fosseardeatine";
     
          $conn = new mysqli($host, $username, $password, $database);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $query = "select id,nome from Citta";
            $result = $conn->query($query);

            echo '<div class="seleziona">';
            echo '<label for="lang"><b>Seleziona Paese Caduti </b></label>';
            echo '<select name="ciociari" id="ciociari" onchange="showBox()">';
            echo '<option value="Home">Altri</option>';

            if ($result->num_rows > 0) {
                while($colums = $result->fetch_assoc()){
                    echo '<option value='.$colums["id"].'>'.$colums["nome"].'</option>';
                }
            }
            echo '</select>';
            echo '</div>';

            $conn->close();
        ?>
    <div class="header_ciociaria">
        <div class="foto_person"></div>
        <div class="text_ciociari"></div>
    </div>

    <div class="header_centrale">
        <div class="box_person"><div id="orlando"></div></div>
        <div class="text_person"><h3>Orlando Orlandi Posti</h3><p><b>Nascita e infanzia</b><br>
            Orlando Orlandi Posti nacque a Roma il 14 marzo 1926. Era figlio di un impiegato statale e di una casalinga. Frequentò l'Istituto Magistrale "Giosuè Carducci" e si distingueva come un ragazzo vivace,intelligente e con una forte passione per la giustizia.
            <br><br><b>Attività antifascista</b><br>
            Nell'estate del 1943, all'età di 17 anni, aderì al Partito d'Azione e si unì all'Associazione Rivoluzionaria Studentesca Italiana (ARSI). Si impegnò attivamente nella Resistenza romana, partecipando a diverse azioni contro l'occupante tedesco.
            <br><br><b>Il 3 febbraio 1944</b><br>
            Il 3 febbraio 1944, durante una retata nazista nel quartiere Montesacro di Roma, Orlandi avvisò i suoi compagni antifascisti del pericolo, permettendo loro di fuggire. Tuttavia, venne catturato dalle SS mentre cercava di raggiungere la sua abitazione.
            <br><br><b>Prigionia e morte</b><br>
            Orlandi fu rinchiuso nel carcere di via Tasso a Roma, dove venne sottoposto a torture e interrogatori. Condannato a morte senza processo, fu fucilato alle Fosse Ardeatine il 24 marzo 1944, insieme ad altri 334 prigionieri.
            <br><br><b>Eridità</b><br>
            Per il suo coraggio e sacrificio, Orlando Orlandi Posti è stato insignito della Medaglia d'argento al valor militare alla memoria. Le sue lettere dal carcere sono state pubblicate in un libro intitolato "Roma '44". La sua storia rappresenta un esempio di impegno civile e un monito contro la tirannia per le nuove generazioni.
        </p></div>
        
        <div class="box_person"><div id="ilario"></div></div>
        <div class="text_person"><h3>Ilario Canacci</h3><p><b>Nascita e infanzia</b><br>
            Ilario Canacci nacque a Roma il 12 febbraio 1927. Non conobbe mai il padre naturale, Antonio La Bruna, e venne affidato alla famiglia di Arduino Veloccia ed Ersilia Calabrese ad Alatri, che lo crebbero con amore. Mantenne regolari rapporti con la madre Rina Canacci e la sorella Anna Maria a Roma fino all'età di 14 anni, quando l'assistenza dell'Opera Nazionale Maternità e Infanzia (ONMI) venne meno.
            <br><br><b>Attività partigiana</b><br>
            Nel 1943, all'età di 16 anni, Canacci si unì al gruppo partigiano Movimento Comunista d'Italia–Bandiera Rossa nella borgata Gordiani di Roma. Il suo gruppo compiva azioni di sabotaggio contro l'occupante tedesco, in particolare contro il piccolo aeroporto di Centrocelle.
            <br><br><b>Arresto e morte</b><br>
            Il 17 febbraio 1944, Canacci fu arrestato dai nazisti durante un rastrellamento. Venne rinchiuso nel carcere di via Tasso a Roma, dove subì torture e interrogatori. Condannato a morte senza processo, fu fucilato alle Fosse Ardeatine il 24 marzo 1944, a soli 17 anni.
            <br><br><b>Eredità</b><br>
            Ilario Canacci è stato una delle più giovani vittime dell'eccidio delle Fosse Ardeatine. La sua storia rappresenta un esempio di coraggio e sacrificio per la libertà e la democrazia. A lui sono intitolate una scuola media ad Alatri e una via a Roma.
        </p></div>
        <div class="box_person"><div id="palatucci"></div></div>
        <div class="text_person"><h3>Giovanni Palatucci</h3><p><b>Nascita e infanzia</b><br>
            Giovanni Palatucci nacque a Montella, in provincia di Avellino, il 31 maggio 1909. Era figlio di un magistrato e di una casalinga. Frequentò il liceo classico a Benevento e si laureò in giurisprudenza all'Università di Torino nel 1932. Era un giovane intelligente e sensibile, con una forte passione per la giustizia.
            <br><br><b>Attività lavorativa e impegno antifascista</b><br>
            Nel 1936, Palatucci entrò a far parte della pubblica sicurezza. Venne assegnato a Genova e poi a Fiume, dove divenne questore reggente nel 1943. In questa posizione, Palatucci si distinse per il suo coraggio e la sua umanità. Aiutò molti ebrei a sfuggire alle persecuzioni naziste, fornendo loro documenti falsi e aiutandoli a fuggire in Svizzera.
            <br><br><b>Arresto e morte</b><br>
            Nel settembre del 1944, Palatucci fu arrestato dai nazisti e deportato nel campo di concentramento di Dachau. Venne sottoposto a torture e privazioni, ma non rinunciò mai ai suoi principi. Morì il 10 febbraio 1945, a soli 35 anni, pochi giorni prima della liberazione del campo.
            <br><br><b>Eredità</b><br>
            Giovanni Palatucci è stato riconosciuto come Giusto tra le Nazioni dallo Yad Vashem nel 1995. Nel 2004, è stato proclamato Servo di Dio dalla Chiesa cattolica. La sua storia rappresenta un esempio di coraggio, altruismo e speranza.
        </p></div>
        <div class="box_person"><div id="finzi"></div></div>
        <div class="text_person"><h3>Aldo Finzi</h3><p><b>Nascita e infanzia</b><br>
            Finzi nacque a Milano il 4 febbraio 1897 da una famiglia ebrea benestante. Fin dalla giovane età mostrò un grande talento per la musica, studiando pianoforte e composizione. Si laureò in giurisprudenza all'Università di Pavia nel 1920, ma la sua vera passione era la musica.
            <br><br><b>Carriera musicale</b><br>
            Nel 1920, Finzi si trasferì a Roma per studiare composizione al Conservatorio di Santa Cecilia. Si diplomò nel 1924 e iniziò a comporre musica da camera, Lieder e musica orchestrale. Le sue opere furono eseguite in Italia e all'estero, e ricevette diversi premi per la sua musica, tra cui il Premio Marinuzzi nel 1924 e la Guggenheim Fellowship nel 1931.
            <br><br><b>Impegno antifascista</b><br>
            Finzi era un antifascista convinto e nel 1921 aderì al Partito Comunista Italiano. Durante la Seconda Guerra Mondiale, partecipò attivamente alla Resistenza italiana contro l'occupazione nazista.
            <br><br><b>Arresto e morte</b><br>
            Nel febbraio 1944, Finzi fu arrestato dai nazisti a Milano. Fu incarcerato nel carcere di San Vittore, dove subì torture e privazioni. Fu deportato nel campo di concentramento di Fossoli di Carpi, dove venne fucilato il 28 febbraio 1944, a soli 47 anni.
            <br><br><b>Eredità</b><br>
            Aldo Finzi è stato un uomo che ha dedicato la sua vita alla musica e alla libertà. La sua musica è ancora oggi apprezzata e eseguita in tutto il mondo. La sua storia è un esempio di coraggio e sacrificio per la libertà.
        </p></div>
    </div>

<div class="timeline">
    <div class="linea">
        <div class="pallino"></div> 
        <div class="pallino"></div> 
        <div class="pallino"></div>   
        <div class="pallino"></div>
        <div class="pallino"></div>
        <div class="pallino"></div> 
    </div>
    <div id="box1"><h4>1 Settembre 1939 Scoppio II guerra Mondiale<button onclick="popUP()"><p>leggi di più</p></button></h4></div>
    <div id="box2"><h4>10 Giugno 1940 Discorso di Mussolini sull'entrata in guerra d'Italia<button class="b2" onclick="popUP2()"><p>leggi di più</p></button></h4></div>
    <div id="box3"><h4>La potenza nazista è implacabile<button onclick="popUP3()"><p>leggi di più</p></button></h4></div>
      <div id="box4"><h4>23 Marzo 1944 Attentato via Rasella<button  onclick="popUP4()"><p>leggi di più</p></button></h4></div>
    <div id="box5"><h4>24 Marzo 1944 Eccidio delle Fosse Ardeatine<button onclick="popUP5()"><p>leggi di più</p></button></h4></div>
    <div id="box6"><h4>2 Settembre 1945 Fine della II guerra mondiale<button onclick="popUP6()"><p>leggi di più</p></button></h4></div>
</div>

<div class="overlay" id="pop">
	<div class="popup">
		<h2>1 Settembre 1939 Scoppio II guerra Mondiale</h2>
		<p>L'11 settembre 1939 segna l'inizio della Seconda Guerra Mondiale quando la Germania nazista di Adolf Hitler invade la Polonia. Il termine "blitzkrieg," una tattica militare caratterizzata da rapidità e concentrazione d'attacco, fu impiegato per sopraffare velocemente la Polonia. Questo evento oscuro e decisivo segnò una svolta nella storia, dando il via a uno dei conflitti più devastanti mai visti.
La Polonia, teatro iniziale delle ostilità, fu brutalmente divisa tra la Germania e l'Unione Sovietica in base al patto Molotov-Ribbentrop. L'occupazione nazista portò a sofferenze inimmaginabili per la popolazione polacca, segnando l'inizio di una serie di eventi che avrebbero plasmato il destino di interi continenti.
La risposta alleata, accelerata dal trattato di difesa reciproca, accelerò la diffusione del conflitto in Europa e oltre. Questo segnò l'inizio di una fase tumultuosa, con le potenze mondiali coinvolte in un teatro di guerra che avrebbe abbracciato il mondo intero. La guerra si estese nei continenti africano e asiatico, coinvolgendo nazioni e culture diverse in una lotta per la libertà e la sopravvivenza.
L'invasione della Polonia fu il preludio a una serie di eventi che avrebbero plasmato il corso della storia mondiale. L'ascesa del nazismo, la propaganda di massa e le atrocità commesse durante il conflitto sono solo alcune delle sfaccettature complesse di questo periodo oscuro. La Seconda Guerra Mondiale rappresentò un punto di svolta epocale, con conseguenze profonde e durature per le generazioni future.
Nel contesto di questa imponente narrazione storica, l'11 settembre 1939 rimane un anniversario che richiama una riflessione profonda sulla fragilità della pace e sulla necessità di impegnarsi per un mondo libero da conflitti. La blitzkrieg in Polonia fu solo l'inizio di una tempesta globale, con il suo impatto ancora visibile nelle memorie storiche e nelle lezioni apprese dalla tragedia della Seconda Guerra Mondiale.</p>
		<span id="close-popup">X</span>
	</div>
</div>

<div class="overlay2" id="pop2">
	<div class="popup">
		<h2>10 Giugno 1940 Discorso di Mussolini sull'entrata in guerra d'Italia</h2>
		<p>Il 10 giugno 1940, Benito Mussolini, il leader del regime fascista italiano, pronunciò un discorso storico a Piazza Venezia, annunciando l'entrata dell'Italia nella Seconda Guerra Mondiale al fianco delle potenze dell'Asse. Questo momento cruciale segnò una svolta significativa nel conflitto mondiale, innescando una serie di eventi che avrebbero plasmato il corso della guerra e influenzato il destino di intere nazioni.
La dichiarazione di guerra contro la Francia e il Regno Unito segnò l'allargamento dei teatri operativi nel Mediterraneo, aprendo nuove frontiere di combattimento e rendendo la guerra più complessa e globale. L'Italia si unì così alle forze dell'Asse, in alleanza con la Germania nazista e il Giappone, formando una coalizione che cercava di consolidare la propria egemonia in varie regioni del mondo.
Il discorso di Mussolini non solo annunciò un impegno militare cruciale, ma sottolineò anche l'aspirazione dell'Italia a rivendicare un ruolo di primo piano nella politica internazionale. La decisione di entrare in guerra segnò una fase critica del regime fascista, esponendo l'Italia a una serie di sfide militari e diplomatiche.
Con il Mediterraneo come teatro strategico, l'Italia intraprese operazioni militari in Africa settentrionale e nei Balcani, cercando di espandere il proprio dominio e influenzare la geografia della guerra. Tuttavia, le ambizioni dell'Asse non furono sempre coronate da successo, e l'entrata in guerra dell'Italia portò con sé una serie di conseguenze che avrebbero influenzato il corso degli eventi negli anni successivi.
Il discorso a Piazza Venezia e la dichiarazione di guerra di Mussolini rappresentano dunque un momento cruciale nella storia italiana e mondiale del XX secolo, segnando l'inizio di una fase intensa e complessa della Seconda Guerra Mondiale, con ripercussioni che avrebbero plasmato il futuro della nazione e del conflitto in corso.</p>
		<span id="close-popup2">X</span>
	</div>
</div>


<div class="overlay3" id="pop3">
	<div class="popup">
		<h2>La potenza nazista è implacabile</h2>
		<p>Nel 1942, le forze dell'Asse raggiunsero il culmine della loro potenza in Europa, stabilendo un controllo serrato su vasti territori. La Francia era ormai occupata, e le truppe tedesche esercitavano un dominio oppressivo su molte regioni del continente. Questo periodo, segnato da un'apparente supremazia dell'Asse, gettò un'ombra oscura sull'Europa, ma allo stesso tempo, l'anno portò con sé una serie di sfide significative e preludi a eventi che avrebbero cambiato il corso della storia.
Mentre le truppe naziste si estendevano, parallelamente cresceva la brutalità delle politiche antisemite del regime di Hitler. Gli ebrei d'Europa erano oggetto di persecuzioni sempre più sistematiche, con la creazione di ghetti e l'avvio delle deportazioni verso i campi di concentramento. Questo periodo vide l'ascesa del nazismo a un nuovo livello di crudeltà, prefigurando gli orrori dell'Olocausto che sarebbero seguiti.
L'anno 1942, pur rappresentando l'apice della potenza nazista, fu contrassegnato dall'inizio di sfide significative per l'Asse. La svolta decisiva arrivò con la Battaglia di Stalingrado nel 1943 sul Fronte Orientale. Questa battaglia, tra le più sanguinose della storia, fu un punto di svolta cruciale, indebolendo le forze dell'Asse e segnando l'inizio del loro declino.
La potenza nazista, una volta inarrestabile, iniziò a mostrare le prime crepe, e la resistenza emergente nei territori occupati si intensificò. Le vittorie apparentemente imponenti si trasformarono in una lotta per il mantenimento del controllo, mentre le forze alleate si organizzavano per contrattaccare e liberare le nazioni oppresse.
Così, il 1942 non solo rappresentò l'apice della potenza nazista in Europa, ma fu anche un periodo di emergenti sfide e cambiamenti. La tragica persecuzione degli ebrei, la crescita della resistenza e la svolta nella Battaglia di Stalingrado anticiparono il declino dell'Asse e segnarono il cammino verso la fine della Seconda Guerra Mondiale.</p>
		<span id="close-popup3">X</span>
	</div>
</div>


<div class="overlay4" id="pop4">
	<div class="popup">
		<h2>23 Marzo 1944 Attentato via Rasella</h2>
		<p>Il 23 marzo 1944 rimane un capitolo significativo nella storia della Resistenza italiana durante la Seconda Guerra Mondiale. In quell'audace giornata, i partigiani italiani decisero di compiere un attacco temerario a Via Rasella a Roma, mirando direttamente alle forze di occupazione tedesche. L'azione, intrapresa con coraggio e determinazione, tuttavia, avrebbe portato a una serie di eventi drammatici che avrebbero segnato la lotta della Resistenza contro l'occupazione nazista.
L'attentato a Via Rasella fu un gesto di sfida aperta contro le truppe tedesche che controllavano la capitale italiana. La situazione politica ed emotiva era tesa, e la popolazione romana e la Resistenza sentivano l'urgente necessità di ribellarsi contro il regime fascista e l'occupazione straniera. L'audacia degli attivisti partigiani rifletteva un desiderio profondo di libertà e la volontà di sacrificare tutto per la causa della Resistenza.
Tuttavia, le conseguenze dell'attacco furono tragiche. Le rappresaglie tedesche furono brutali e spietate, intensificando la repressione e provocando una spirale di violenza. La Resistenza, già attiva nel tessuto sociale italiano, trovò nuova forza nell'indignazione generata dalle rappresaglie, ma al contempo, la situazione divenne sempre più tesa e instabile.
La Resistenza italiana, alimentata da un mix di patriottismo, rabbia e determinazione, vide aumentare la sua influenza e il sostegno popolare. La lotta contro l'occupazione nazista e il regime fascista si intensificò, diventando un catalizzatore per la crescente opposizione nella popolazione. La Resistenza non era più solo un fenomeno di guerriglia, ma si trasformò in una forza motrice che avrebbe contribuito a definire il futuro dell'Italia.
Il 23 marzo 1944, con l'attentato di Via Rasella, si pose così come un momento cardine in cui la Resistenza italiana, nonostante le tragiche conseguenze, si consolidò come un baluardo contro l'oppressione e un faro di speranza per un'Italia libera e indipendente.
</p>
		<span id="close-popup4">X</span>
	</div>
</div>


<div class="overlay5" id="pop5">
	<div class="popup">
		<h2>24 Marzo 1944 Eccidio delle Fosse Ardeatine</h2>
		<p>Il 24 marzo 1944 segna una pagina di profonda tragedia nella storia della Seconda Guerra Mondiale e dell'Olocausto. In risposta all'audace attentato di Via Rasella a Roma, le truppe tedesche perpetrarono una rappresaglia senza precedenti alle Fosse Ardeatine. Questo atto brutale ebbe conseguenze devastanti, in quanto 335 uomini, tra cui ebrei, prigionieri politici e civili innocenti, furono brutalmente uccisi e sepolti nelle cave vicino a Roma.
L'uccisione di queste 335 persone rappresentò un esempio aberrante della crudeltà delle rappresaglie naziste contro la Resistenza e la popolazione civile. Il numero di vittime era straordinario, e l'atto fu eseguito con un cinismo e una ferocia che testimoniavano la disumanizzazione perpetrata dalla macchina di guerra nazista.
L'atto alle Fosse Ardeatine, insieme all'Olocausto in corso, evidenzia la barbarie senza limiti che caratterizzò il regime nazista. La tragedia alle Fosse Ardeatine è un simbolo dei costi umani devastanti del conflitto e dell'importanza di ricordare le vittime innocenti. Questo capitolo oscuro sottolinea l'urgenza di preservare la memoria storica per garantire che simili orrori non si ripetano mai più e che il mondo aspiri sempre a un futuro basato sulla pace, sulla tolleranza e sul rispetto per la vita umana.</p>
		<span id="close-popup5">X</span>
	</div>
</div>

<div class="overlay6" id="pop6">
	<div class="popup">
		<h2>2 Settembre 1945 Fine della II guerra mondiale</h2>
		<p>La Seconda Guerra Mondiale è stato un conflitto di proporzioni globali che ha coinvolto la maggior parte delle nazioni del mondo. La guerra è durata dal 1939 al 1945 e ha causato la morte di milioni di persone.
La resa della Germania nazista e del Giappone ha segnato la fine del conflitto. In Europa, l'occupazione nazista è stata finalmente terminata e le nazioni hanno iniziato a ricostruire le loro città e le loro economie distrutte dalla guerra. La scoperta dei campi di concentramento nazisti ha portato alla luce l'orrore dell'Olocausto e ha spinto il mondo ad affrontare la questione della responsabilità e della memoria storica.
Nel Pacifico, l'utilizzo di bombe atomiche contro le città giapponesi di Hiroshima e Nagasaki ha avuto un impatto devastante e ha inaugurato una nuova era di potenziale distruzione di massa.
Le sfide della ricostruzione postbellica hanno portato le nazioni a collaborare a livello internazionale e a creare istituzioni come le Nazioni Unite per promuovere la pace e la sicurezza nel mondo. La Seconda Guerra Mondiale ha anche portato a una profonda riflessione sulla natura umana e sulla necessità di costruire una pace duratura.
Il costo umano della guerra è stato immenso. L'Olocausto e le bombe atomiche sono solo due esempi delle atrocità che hanno avuto luogo durante il conflitto. La memoria di queste atrocità serve a sottolineare l'importanza di impegnarsi per la pace, la giustizia e la comprensione reciproca.
La Giornata della memoria, celebrata ogni anno il 27 gennaio, è un giorno dedicato alla commemorazione delle vittime dell'Olocausto. È un momento per ricordare gli eventi passati e per impegnarsi a costruire un futuro migliore.
La Seconda Guerra Mondiale è stata un evento epocale che ha modellato il futuro del mondo. La sua conclusione ha portato alla ricostruzione, alla riflessione e all'impegno per la pace. La memoria delle sue atrocità rimane un monito per le generazioni future.</p>
		<span id="close-popup6">X</span>
	</div>
</div>
</body>
</html>

