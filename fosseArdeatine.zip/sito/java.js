function showBox(){
    var ciociari = document.getElementById("ciociari").value;
    var header_centrale = document.querySelector(".header_centrale");
    var header_ciociaria = document.querySelector(".header_ciociaria");
    var size = window.innerWidth;
    var xmlhttp = new XMLHttpRequest();
    
    xmlhttp.onreadystatechange = function(){
        if (this.readyState == 4 && this.status == 200){
            if (size > 768){
                document.querySelector(".header_ciociaria").innerHTML = this.responseText;
                header_centrale.style.display = "none";
                header_ciociaria.style.display = "grid";

                if(ciociari == "Home"){
                    header_ciociaria.style.display = "none";
                    header_centrale.style.display = "grid";
                }
            } 
            if(size <= 768){
                document.querySelector(".header_ciociaria").innerHTML = this.responseText;
                header_centrale.style.display = "none";
                header_ciociaria.style.display = "inline";

                if(ciociari == "Home"){
                    header_ciociaria.style.display = "none";
                    header_centrale.style.display = "inline";
                }
            }
    }};
    var url = "https://fosseardeatine.altervista.org/ajax.php?citta=" + ciociari;
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

function popUP(){
    var overlay = document.querySelector(".overlay");
    overlay.style.display = "block";


    const closePopupButton = document.getElementById("close-popup");

    closePopupButton.addEventListener("click", () => {
    const popupElement = document.getElementById("pop");
    popupElement.style.display = "none";
    });
}

function popUP2(){
    var overlay = document.querySelector(".overlay2");
    overlay.style.display = "block";


    const closePopupButton = document.getElementById("close-popup2");

    closePopupButton.addEventListener("click", () => {
    const popupElement = document.getElementById("pop2");
    popupElement.style.display = "none";
    });
}

function popUP3(){
    var overlay = document.querySelector(".overlay3");
    overlay.style.display = "block";


    const closePopupButton = document.getElementById("close-popup3");

    closePopupButton.addEventListener("click", () => {
    const popupElement = document.getElementById("pop3");
    popupElement.style.display = "none";
    });
}

function popUP4(){
    var overlay = document.querySelector(".overlay4");
    overlay.style.display = "block";


    const closePopupButton = document.getElementById("close-popup4");

    closePopupButton.addEventListener("click", () => {
    const popupElement = document.getElementById("pop4");
    popupElement.style.display = "none";
    });
}

function popUP5(){
    var overlay = document.querySelector(".overlay5");
    overlay.style.display = "block";


    const closePopupButton = document.getElementById("close-popup5");

    closePopupButton.addEventListener("click", () => {
    const popupElement = document.getElementById("pop5");
    popupElement.style.display = "none";
    });
}

function popUP6(){
    var overlay = document.querySelector(".overlay6");
    overlay.style.display = "block";


    const closePopupButton = document.getElementById("close-popup6");

    closePopupButton.addEventListener("click", () => {
    const popupElement = document.getElementById("pop6");
    popupElement.style.display = "none";
    });
}